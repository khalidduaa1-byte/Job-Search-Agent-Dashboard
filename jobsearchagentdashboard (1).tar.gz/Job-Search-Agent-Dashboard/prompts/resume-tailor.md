# Tailoring the resume

Called by `daily-search.md` for the single highest-scoring posting of the morning, and only when
it scored 80 or above.

Read `profile.md` first. The master resume is the fixed input, and that is the whole point:
tailoring is a **diff against one document**, not a fresh write. A resume rewritten from scratch
every morning drifts, and by week three the claims no longer match each other or the master.

---

You are tailoring Duaa Khalid's master resume for one specific posting.

## What you may change

- **Ordering.** Move the most relevant role or project up. This is the highest-value edit and
  usually the only one needed.
- **Bullet selection.** Keep the bullets that speak to the posting, drop the ones that do not.
  Dropping is allowed. Rewriting is mostly not.
- **Emphasis inside a bullet.** Lead with the part the posting cares about. The same tracker
  bullet leads with the dedup pipeline for a data role and with the 18-advisor rollout for a
  deployment role. Same facts, different first clause.
- **The summary line.** Two sentences at most, pointed at this role. This is where the tailoring
  should be most visible.
- **Vocabulary, only where it is genuinely the same thing.** If the posting says "time to
  value" and the master says "cut ordering time from 45 minutes to 5", using their phrase for
  her result is fair. Using their phrase for something she did not do is not.

## What you must not change

- **Every number stays exactly as written in `profile.md`.** 1,324 rows. 0 rejected. 29
  duplicates. 18 advisors. 45 minutes to 5. 13 markets. 20 of 31 items. AED 8,400 against AED
  10,688. 78.6%. Do not round, do not convert, do not recompute, do not upgrade a number
  because the posting mentions scale.
- **Job titles as held.** The site and the ADM and CSM resume variants say "Customer Success and
  Key Account Manager". Do not retitle a role to match a posting. If a posting wants a title she
  did not hold, that is a gap, not a formatting problem.
- **Dates and employers.** Never adjusted.
- **Nothing about Homebase becomes a shipped product.** It is a hackathon build with no
  production usage. Its compliance layer is specified, not built. Never call it live, never call
  it a product, and never cite its README's unsourced stats.
- **No link to `github.com/bm2515/homebase`.** It is the co-founder's private repo and it 404s
  for every visitor.
- **No new skills, tools, certifications or languages.** If it is not in `profile.md`, it does
  not go on the resume, however well it would match.

## Handling a gap

When the posting requires something she does not have, the answer is ordering and honesty, not
invention.

- Lead with the nearest real thing. For "shipped ML to production", the nearest real thing is
  the ingest pipeline and the evaluation work on Homebase's voice-agent logs, described as
  exactly that.
- Do not add a "familiar with" line to cover a gap. It reads as a gap with a label on it, and
  it will be asked about in the screen.
- If more than about a third of the requirements are gaps, say so in the email note rather than
  stretching the document. That is a signal the score was too high, and it should feed back into
  the rubric.

## Output

1. **The tailored resume**, as a document attached to the morning email. Same layout as the
   master. One page.
2. **A one-line note for the email**, stating what you actually changed. `Led with the tracker
   rollout and the 18-advisor adoption, dropped the move-out project, rewrote the summary
   around deployment.`

That note is the audit trail. If it ever reads `tailored the resume for this role`, the
tailoring did not happen and the note is covering for it.

## Hard rules

- **No em dashes.**
- Contact is `dk947@cornell.edu`, including in link text. Check case-insensitively: an all-caps
  gmail address survived a case-sensitive find and replace once.
- Never invent a metric, a title, a date, or a tool.
- If you cannot honestly tailor for this posting, say so in one line and attach nothing.
