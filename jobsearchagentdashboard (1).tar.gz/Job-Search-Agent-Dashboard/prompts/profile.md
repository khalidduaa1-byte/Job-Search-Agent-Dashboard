# The profile

The shared input for every prompt in this folder. Keep it in one file so a correction lands
once instead of three times.

Everything here is verified. **Do not add to it, and do not soften it.** If a posting asks for
something that is not on this list, the honest answer is that she does not have it, and the
score should say so.

## Who

Duaa Khalid. Five years in commercial and GTM across luxury retail, MENA and travel retail.
Incoming MEng, Data Science and Decision Analytics, Cornell Tech, starting August 2026. Moving
Dubai to New York. Contact `dk947@cornell.edu`.

## What she is targeting

In priority order:

1. **AI deployment and post-sales adoption.** The OpenAI "AI Deployment Manager" shape:
   deploying a model or platform into a customer's real operation, then owning enablement and
   adoption. This is the closest match to what she has actually done.
2. **AI product management**, and technical or platform product roles where the product is a
   decision system rather than a consumer surface.
3. **Forward-deployed and solutions roles** that are customer-facing and implementation-heavy.
4. **Product strategy and product operations** at AI-native companies.

Company shape: model labs, AI platform and tooling companies, AI-native SaaS.

Geography: **United States only.** New York from August 2026, and remote-US roles are equally
good, from anywhere in the country. On-site, hybrid and remote are all fine as long as the role
is in the US.

**Nothing outside the United States.** Not Dubai, not the UK, not remote roles that are not
US-eligible. She is moving to New York and the search is for roles she can actually take. A
non-US posting is not a low score, it is out of scope: do not return it at all.

Within that, the brief is wide. Any US role that is genuinely among the best she could get,
across every title family below, is worth surfacing.

## What she has actually done

- **Internal product owner, sell-in decision support tool** (LVMH, Givenchy and Kenzo). Took
  placing one account order from 45 minutes to 5, across 30 plus MENA locations. Two years of
  defining requirements, prioritising the roadmap and running feedback loops with the account
  managers who used it daily. First time she was the single point of contact across retailers,
  marketing, demand planning and supply chain.
- **Account health monitoring layer** (Dolce and Gabbana Beauty). Benchmarks accounts across a
  13-market portfolio and flags the at-risk ones. Now the primary decision input across all 13.
- **Beauty Advisor Sales Tracker.** A PWA where 18 advisors log daily sales, behind a Python
  ingest pipeline that de-duplicates a supervisor's Excel export before any KPI is calculated.
  The dedup key is advisor plus date plus store plus shift. One full run across January to
  April: 1,324 rows ingested, 0 rejected, 29 duplicates removed. Live across Cairo, Sharm and
  Hurghada with advisors who were **not required to use it**. Presented to global beauty
  leadership.
- **Field rollout and enablement.** Onboarded and trained roughly 20 field users into sustained
  daily use, on top of building and delivering sales enablement workshops for a 30 plus person
  beauty advisor team.
- **Move-Out Sale generator.** One Python script produces the buyer-facing catalog and the
  internal profit tracker from a single item list, so the listing and the accounting cannot
  disagree. 20 of 31 items sold in 30 days, AED 8,400 recovered against AED 10,688 paid.
- **Homebase**, co-founded, hackathon build. A fixed-format context block a voice agent uses to
  dispatch maintenance vendors. Deterministic template by default, the model path behind an
  explicit `USE_LLM_SCOPE=true` flag. She owned problem framing and the UAE rental regulation
  model: RERA bands, the 90-day notice rule, Ejari sequencing, the bilingual requirement.

## What she has not done

State this plainly when a posting requires it. Do not paper over it.

- Has **not** shipped a machine learning model to production.
- Has **not** worked at engineering scale. Largest user base here is 18 people; largest data
  volume is a few thousand rows.
- Has **not** managed engineers.
- Homebase's RERA compliance layer is **specified, not built**, and is listed as out of scope
  in its own README.
- No formal software engineering background. Python and SQL are working tools, not a
  specialism.

## Positioning, in her words

"Most of my work starts inside someone else's spreadsheet. A supervisor's export, a catalog
price, a phone call assembled from memory. The model is rarely the interesting part. Deciding
what counts as a valid row is, and so is getting a field team in another country to work the
new way."

## Writing rules

- **No em dashes.** Commas or full stops.
- Contact is `dk947@cornell.edu` everywhere.
- Never invent a metric. If a number is not in this file, it does not exist.
