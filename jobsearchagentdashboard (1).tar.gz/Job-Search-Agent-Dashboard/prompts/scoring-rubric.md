# The scoring rubric

A score is a claim about fit. It has to mean the same thing on Monday as it does on Thursday,
or the ordering in the dashboard is noise and the 90-plus count on the stat row is meaningless.

Read `profile.md` first. Score against what is actually in it.

## The bands

| Band | Score | What it means |
| --- | --- | --- |
| `strong` | 90 to 100 | Apply this week. The core of the job is work she has done, and nothing in the requirements is disqualifying |
| `possible` | 70 to 89 | Worth reading properly. Real overlap, with one clear gap or a compromise on level, scope or geography |
| `weak` | below 70 | Logged so the low band is visible rather than silently dropped. Not worth her morning |

The dashboard derives the band from the score, so **do not try to make them disagree**. If a
posting feels like a 95 but you can only justify 80, the score is 80.

## How to build a score

Start at zero and add. Then apply the caps, which are not optional.

**Role core, up to 45.** How much of the day-to-day is work in `profile.md`?

- 45: owns deployment or adoption of a platform inside a customer's operation
- 38: product ownership of an internal decision or data tool
- 30: post-sales, enablement or solutions work at a technical company
- 20: adjacent commercial or programme work
- 10: analyst work executing against someone else's spec

**Domain and system fit, up to 20.** Does the posting describe the specific problem she is good
at? Unreliable operational input, defining what a valid record is, getting a non-technical team
to adopt something. Full marks need the posting to say so, not for you to infer it.

**Geography and timing, up to 15.** Any United States role gets 15, whether it is New York,
another US city, or remote-US. There is no geographic preference inside the country, so do not
score a New York role above an Austin one on location alone.

Roles outside the US score nothing here, and are excluded entirely by the rule below.

**Company shape, up to 12.** A model lab, AI platform or AI-native SaaS gets 12. A traditional
company with an AI initiative gets 6. No AI dimension gets 0.

**Evidence the search is live, up to 8.** On the employer's own board and recently posted or
reposted gets 8. An aggregator listing you could not confirm gets 2.

## The caps. These override everything above.

- **Requires an ML model shipped to production, or engineering management: cap at 65.** She has
  not done either, and a 90 here wastes her week.
- **Requires 8 or more years in the exact function: cap at 75.**
- **Explicitly refuses visa sponsorship: cap at 40**, and say so in the rationale. Do not guess
  her immigration status, and if the posting is silent on sponsorship, do not apply this cap and
  do not raise the subject.
- **Requires a security clearance: cap at 20.**
- **Not a United States role: do not emit the record at all.** This is a filter, not a penalty.
  A role in London or Dubai is out of scope however good it is, and a weak-band non-US listing
  on the board is just noise she has to hide by hand. Remote roles count as US only if they say
  they are open to US-based candidates.
- **Cannot open the posting or confirm it exists: do not emit the record at all.** A
  hallucinated opportunity is worse than a missed one, because it costs her a morning and it
  teaches her not to trust the board.

## The rationale field

One sentence. It has to survive being read three weeks later by someone deciding whether to
still apply.

- Name the specific overlap, not the category. "Owns adoption for an enterprise AI platform,
  which is the tracker rollout with a bigger customer" beats "great fit for her background".
- **Name the gap in the same sentence** when the score is below 90. The gap is the useful part.
- No adjectives about her. No "exciting opportunity". No pitch.

Good: `Post-sales adoption ownership for an AI platform, closest match to the deployment track,
but the posting asks for five years of enterprise SaaS she does not have.`

Bad: `Excellent alignment with Duaa's impressive background in AI and product.`

## Calibration check

Before emitting a digest, look at the set. If more than about a third of what you found is
`strong`, you have drifted, and the fix is to re-read the caps rather than to shuffle scores.
A normal morning is one or two strong, a handful of possible, and some weak.

Where a posting is genuinely borderline, score it lower and say why in the rationale. The cost
of a missed 88 is that she reads it on Friday in the roundup. The cost of an inflated 94 is
that she stops believing the number.
