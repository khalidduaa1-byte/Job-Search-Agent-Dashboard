# Daily search, Monday to Thursday

Paste this into a **Claude scheduled task** set to run on weekday mornings, Monday through
Thursday. Attach or paste `profile.md` and `scoring-rubric.md` alongside it, and attach the
master resume.

---

You are running Duaa Khalid's morning job search. Web search is on. Work through this in order.

## 1. Search

Cover, in this order:

1. **The employer boards on the watchlist.** Anything in `ingest/sources.json` plus any company
   she has told you to track. An employer's own careers page is the best source available: if
   the posting is live there today, the search is real.
2. **The major job boards and aggregators** for the target titles in `profile.md`. Titles worth
   querying: AI Deployment Manager, Forward Deployed Engineer or Product Manager, Solutions
   Architect, AI Product Manager, Technical Product Manager, Customer Success Manager at AI
   companies, Deployment Strategist, Implementation Manager.
3. **Filters. United States only.** New York, remote-US, and any other US city all count
   equally. Do not return roles outside the US, and do not return remote roles unless they say
   they are open to US-based candidates. Posted or reposted within the last 14 days. Skip
   anything already on the board unless the posting changed, and re-emitting an unchanged
   posting is fine, because the dashboard merges on the posting URL and will report it as
   updated rather than duplicating it.

Inside the US the brief is wide, so do not over-narrow to New York or to one title. The ask is
the best roles she could realistically get, wherever in the country they are.

Aim for **8 to 15 postings**. Fewer is fine on a slow morning. Do not pad the list to hit a
number: a short honest digest is the point of the exercise.

## 2. Verify before you score

For every posting, open it. Then:

- Confirm the role, the employer, the location and the arrangement from the posting itself.
- Prefer the employer's own board URL over an aggregator's redirect, because the aggregator link
  rots first.
- **If you cannot open it or confirm it exists, drop it.** Do not emit a record you could not
  read. One invented posting costs more trust than ten missed ones.

## 3. Score

Apply `scoring-rubric.md` exactly, including the caps. Write one honest sentence per posting for
`rationale`, naming the gap whenever the score is below 90.

## 4. Pick the top opportunity and tailor the resume

Take the highest-scoring posting. Tailor the master resume for it using `resume-tailor.md`.
Attach the tailored resume to the email. Set `resume_tailored` to `true` on that record and
**only** that record.

If nothing scored 80 or above, do not tailor anything. Say so in the email in one line. A
tailored resume for a 62 is wasted work and it teaches her to ignore the attachment.

## 5. Send the email

Subject: `Job search, <weekday> <D Month> — <N> roles, top match <Company> (<score>)`

Body, in this order:

1. **One line** on the morning: how many roles, how many at 90 plus, and the single thing worth
   knowing. If nothing good came up, say that in one line rather than dressing up the list.
2. **The top opportunity.** Company, role, location, score, the rationale, a link to the
   posting, a link to apply, and one line on what the tailored resume changed.
3. **The rest**, ordered by score, one line each: `<score> · <Role> · <Company> · <Location> ·
   <rationale>` followed by the posting link.
4. **The JSON block**, exactly as specified below, under a heading that says
   `Paste into the dashboard`.

Keep the prose short. She reads this on a phone before work.

## 6. Emit the JSON

At the end of the email, output a **single JSON array and nothing else inside the code block**.
No commentary between the objects, no trailing prose inside the fence, no markdown inside the
values.

One object per posting, with exactly these fields:

```json
[
  {
    "title": "AI Deployment Manager",
    "company": "Lumina Systems",
    "location": "New York, NY",
    "remote": "hybrid",
    "source": "greenhouse",
    "url": "https://<canonical posting url>",
    "apply_url": "https://<direct application url>",
    "posted": "2026-07-24",
    "score": 96,
    "rationale": "One sentence, naming the overlap and the gap.",
    "signal": "employer board page active, reposted 2026-07-28",
    "resume_tailored": true
  }
]
```

Field rules, which the dashboard enforces on import:

- `remote` is one of `onsite`, `hybrid`, `remote`, `unknown`. Use `unknown` rather than
  guessing.
- `source` names where you found it: `greenhouse`, `ashby`, `lever`, `adzuna`, `linkedin`,
  `company_site`.
- `posted` is `YYYY-MM-DD`, or `""` when the posting does not say. Do not estimate it.
- `score` is an integer from 0 to 100. Omit `band`; the dashboard derives it.
- **Never emit `status`, `hidden`, or `notes`.** Those are hers. An import that sets them would
  overwrite her triage, and the dashboard is built to ignore them for exactly that reason.

## Hard rules

- **No invented postings, companies, URLs or dates.** Every field traces to a page you opened.
- **No invented facts about her.** Only what is in `profile.md`.
- **No em dashes** anywhere in the email.
- Do not claim a tailored resume is attached unless it is.
- If the search fails or you find nothing, send the email saying so. A quiet morning is
  information. Silence looks like a broken task.
